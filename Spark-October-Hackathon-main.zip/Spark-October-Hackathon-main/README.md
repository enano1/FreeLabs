# Spark-October-Hackathon
Spark October Hackathon

Team Members: 
Grace Wang - grace25@bu.edu
Joey Park - joeypark@bu.edu
Max Greenspan - maxgspab@bu.edu
Paul Enano - enano1@bu.edu
Shashank Ramachandran - sr31@bu.edu


Idea: An open source learning platform that allows people with lower opportunities and resources to learn.
